# Savate

![Savate Specimen](presentations/specimen-savate.png)

Une fonte libre du collectif We.ch

[→ Site de présentation](http://collectif-we.ch/savate)
